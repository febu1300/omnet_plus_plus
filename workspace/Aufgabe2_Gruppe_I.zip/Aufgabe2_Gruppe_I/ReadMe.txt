1. Aufgabe 2.2 behandelt die Punkte 1-4 und befasst sich mit einfachen Modulen. Die Lösung befindet sich im Ordner "tictok".

2. Der Ordner "CompoundedModule" enthält Simulationen, NED- und C++-Dateien sowie Visualisierungen, die für die Punkte ab 5 relevant sind.
