#!/bin/bash

# Monaco SUMO Traffic (MoST) Scenario
#     Copyright (C) 2019
#     Lara CODECA

python3 traci.pypml.example.py -c pmonitor.cfg.json