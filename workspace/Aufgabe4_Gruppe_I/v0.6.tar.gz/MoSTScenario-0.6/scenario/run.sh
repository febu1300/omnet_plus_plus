#!/bin/bash

sumo -c most.sumocfg